<div class="about-us-widget">
    <img src="<?php echo esc_url( $aboutimg ); ?>" alt="">
    <p><?php echo wp_kses_post( $aboutdesc ); ?></p>
</div>