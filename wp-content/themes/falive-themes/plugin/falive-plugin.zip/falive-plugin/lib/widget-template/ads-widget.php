<div class="blog-sidebar-square-ads">
	<a href="<?php echo esc_url( $adsurl ); ?>"><img src="<?php echo esc_url( $adsimage ); ?>" alt="<?php echo esc_attr( $title ); ?>"></a>
</div>