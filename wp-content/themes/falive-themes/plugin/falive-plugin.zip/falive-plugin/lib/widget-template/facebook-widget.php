<div class="blog-fb-likebox">
<div class="fb-like-box" data-href="<?php echo esc_url( $facebookurl ); ?>" data-width="240" data-height="300" data-show-faces="true" data-header="false" data-stream="false" data-show-border="true"></div>
</div>