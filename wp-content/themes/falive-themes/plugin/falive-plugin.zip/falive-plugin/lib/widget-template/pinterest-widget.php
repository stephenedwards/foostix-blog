<div class="blog-pinterest-widget">
    <a data-pin-do="embedUser" href="<?php echo esc_url( $url ); ?>" data-pin-scale-width="82" data-pin-scale-height="340" data-pin-board-width="270"></a>
    <script type="text/javascript" async defer src="//assets.pinterest.com/js/pinit.js"></script>
</div>