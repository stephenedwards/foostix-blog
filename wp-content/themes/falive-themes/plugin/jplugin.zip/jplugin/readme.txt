1.0.0
- Initial Release

1.0.1
- Update font awesome to 4.2.0

1.0.2
- Add wordpress importer script

1.0.3
- VC additional element

1.0.4
- Remove Image size checker on WordPress Importer that causing image import failed